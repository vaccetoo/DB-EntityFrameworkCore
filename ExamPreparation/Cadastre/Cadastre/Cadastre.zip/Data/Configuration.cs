﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=Asus-Tuf;Database=ProductShop;Integrated Security=True";
    }
}
